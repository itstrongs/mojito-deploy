#!/bin/sh

image_name='export_jmx_kafka'

docker build -t ${image_name} .
docker run -v --net=host --name ${image_name} -d -p 12345:12345 ${image_name}